CREATE TRIGGER sakila.payment_date
BEFORE INSERT ON sakila.payment
FOR EACH ROW
  SET NEW.payment_date = NOW();
