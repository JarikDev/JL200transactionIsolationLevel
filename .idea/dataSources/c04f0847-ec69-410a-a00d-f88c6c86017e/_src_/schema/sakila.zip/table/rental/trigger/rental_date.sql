CREATE TRIGGER sakila.rental_date
BEFORE INSERT ON sakila.rental
FOR EACH ROW
  SET NEW.rental_date = NOW();
